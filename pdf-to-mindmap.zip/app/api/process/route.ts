import { NextResponse } from "next/server";
import Anthropic from "@anthropic-ai/sdk";
import { PdfReader } from "pdfreader";

export async function POST(request: Request) {
  if (!process.env.ANTHROPIC_API_KEY) {
    return NextResponse.json(
      { error: "API key not configured" },
      { status: 500 }
    );
  }

  try {
    console.log("Processing PDF...");
    const formData = await request.formData();
    const file = formData.get("file") as File;
    console.log("Gotfile");

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    if (!file.type || file.type !== "application/pdf") {
      return NextResponse.json(
        { error: "Invalid file type. Please upload a PDF." },
        { status: 400 }
      );
    }
    console.log("File type:", file.type);

    const buffer = Buffer.from(await file.arrayBuffer());
    const pdfReader = new PdfReader();
    const pdfData = await new Promise<{ text: string }>((resolve, reject) => {
      let text = "";
      pdfReader.parseBuffer(buffer, (err, item) => {
        if (err) {
          console.error("Error parsing PDF:", err);
          reject(err);
        } else if (!item) {
          resolve({ text });
        } else if (item.text) {
          console.log("PDF item:", item.text);
          text += item.text + " ";
        } else {
          console.log("PDF item:", item);
        }
      });
    });

    const anthropic = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY,
    });
    console.log("PDF data:", pdfData.text);
    const message = await anthropic.messages.create({
      model: "claude-3-opus-20240229",
      max_tokens: 4096,
      messages: [
        {
          role: "user",
          content: `Create a mind map using mermaid diagram syntax based on the following text. Focus on the main concepts and their relationships. Make it clear and concise, you should output only the mermaid diagram and no additional text, your output will be directly used to render the diagram on the screen an example below
mindmap
  root((mindmap))
    Origins
      Long history
      ::icon(fa fa-book)
      Popularisation
        British popular psychology author Tony Buzan
    Research
      On effectiveness<br/>and features
      On Automatic creation
        Uses
            Creative techniques
            Strategic planning
            Argument mapping
    Tools
      Pen and paper
      Mermaid

Text below:

      ${pdfData.text}
`,
        },
      ],
    });
    console.log("Anthropic response:", message);
    let mermaidDiagram = message.content[0].text;
    console.log("Mermaid diagram:", mermaidDiagram);
    // trim multiple ` from start and end of diagram if present
    mermaidDiagram = mermaidDiagram.replace(/^`{3,}/, "").replace(/`{3,}$/, "");

    return NextResponse.json({ diagram: mermaidDiagram });
  } catch (error) {
    console.error("Error processing PDF:", error);
    return NextResponse.json(
      { error: "Error processing PDF" },
      { status: 500 }
    );
  }
}
function pdfParse(buffer: Buffer) {
  throw new Error("Function not implemented.");
}
